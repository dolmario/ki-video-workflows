DOLMARIO – LOCAL TUTORIAL COMPANION
UI-REKONSTRUIERT: open .ui.json in ComfyUI. Four import-verified UI paths.
API-ORIGINAL: unchanged test graph contents, not native UI files.
ANLEITUNG/12: install/start. 13: UI import. 14: model files. 15: licences.
Select your own permitted inputs in LoadImage; no photos or models included.
No new GPU runs validated these UI reconstructions.
Historical tests and failures are not guarantees for your system.
Companion to the Dolmario tutorial series; installation instructions and sources are in ANLEITUNG.
